package dao;

import java.util.List;

public class AnimalDAOBin {

}

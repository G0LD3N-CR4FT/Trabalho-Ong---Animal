package dao;

public class AnimalDAOTemp {

}

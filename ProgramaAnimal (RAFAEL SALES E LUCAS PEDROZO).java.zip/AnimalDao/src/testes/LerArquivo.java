package testes;

public class LerArquivo {
}

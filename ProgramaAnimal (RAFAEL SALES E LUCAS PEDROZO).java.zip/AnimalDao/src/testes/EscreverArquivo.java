package testes;

public class EscreverArquivo {
}
